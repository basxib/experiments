public class Plateau
{

    public int Width{get;}
    public int Length{get;}
    public Plateau(int length, int width)
    {
        Width = width; Length = length;

    }

}